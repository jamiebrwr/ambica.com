<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'srh_ambica' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'g90>%~InvQO|3Ud#i/+ |]*,3crq?@ UJA5tc+1FZDPD/g|^e-+AN*OR+/@q)QI7');
define('SECURE_AUTH_KEY',  'z6gdI{W&bV)B*]OY7WKp93E,8t_9`|3YQKG /q+XL%Rb/K;OH02W8!{3$AUMO0Um');
define('LOGGED_IN_KEY',    'weNOOaOB_NTC^toq1IUz8$ktBjNHlj9JV>!6YogutudgwfM-+bD9M/6eQ_%[h8Ln');
define('NONCE_KEY',        '$F{PW3YXz}dk=.&kYDo[}P1}8O[7PXNvw^qh7}-21` {Z[[|[o$Y,~]12*Y-:Ix^');
define('AUTH_SALT',        'C-aZGt69-|HGmy8yypx.P5,Q|@Of<YlDV2|+ g(*-/2D|1{!JBDq |hm{n -OdOD');
define('SECURE_AUTH_SALT', 'Pqz_&uJs$-SSr*-U--o!}HY$3=_%tGH`:bAH/f`tY2)!sy|QI) Ni}m.os5l->{&');
define('LOGGED_IN_SALT',   '~tmnhr4i0]==hdzO:A-q0-^k~ga|a7-@s_.DKX`u^5$BfzIY7:7<WCeao@EH|%]C');
define('NONCE_SALT',       ',^aTJYVAB^[FJ5mdhkU|!#l<Pg Z:)-r|d/|w!VLJ,3Rg_1sS/+-@(.~_,)6m,6 ');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
